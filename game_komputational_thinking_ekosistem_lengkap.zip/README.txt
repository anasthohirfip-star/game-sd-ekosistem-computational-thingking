GAME EDUKASI IPA SD: MISI PENJAGA EKOSISTEM
Computational Thinking | Kelas IV–VI

STRUKTUR FILE
- index.html       : halaman utama game
- css/style.css    : tampilan dan desain game
- js/game.js       : logika permainan, misi, skor, dan umpan balik
- assets/          : folder untuk gambar/audio tambahan (saat ini belum diperlukan)

CARA MENJALANKAN
1. Ekstrak file ZIP.
2. Buka index.html menggunakan browser (Chrome, Edge, Firefox).
3. Game dapat berjalan secara offline; tidak memerlukan instalasi atau internet.

CARA UPLOAD KE GITHUB PAGES
1. Buka repository GitHub Anda.
2. Upload seluruh isi folder ZIP hasil ekstrak (bukan file ZIP-nya saja).
3. Pastikan index.html berada di root repository.
4. Pertahankan folder css dan js beserta isinya.
5. Buka Settings > Pages.
6. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.

Catatan: Jangan memindahkan index.html keluar dari struktur folder ini karena
file tersebut memanggil css/style.css dan js/game.js dengan path relatif.
